'use server';
/**
 * @fileOverview This file implements a Genkit flow for natural language threat inquiry.
 * It allows security analysts to ask questions about alerts or vulnerabilities and receive AI-powered insights.
 *
 * - naturalLanguageThreatInquiry - A function that handles natural language queries about threats.
 * - NaturalLanguageThreatInquiryInput - The input type for the naturalLanguageThreatInquiry function.
 * - NaturalLanguageThreatInquiryOutput - The return type for the naturalLanguageThreatInquiry function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const NaturalLanguageThreatInquiryInputSchema = z.object({
  question: z.string().describe('The natural language question from the security analyst.'),
  context: z.string().optional().describe('Optional contextual information such as alert details, system logs, or vulnerability descriptions.'),
});
export type NaturalLanguageThreatInquiryInput = z.infer<typeof NaturalLanguageThreatInquiryInputSchema>;

const NaturalLanguageThreatInquiryOutputSchema = z.object({
  answer: z.string().describe('A detailed, context-aware explanation or insight provided by the AI.'),
});
export type NaturalLanguageThreatInquiryOutput = z.infer<typeof NaturalLanguageThreatInquiryOutputSchema>;

export async function naturalLanguageThreatInquiry(input: NaturalLanguageThreatInquiryInput): Promise<NaturalLanguageThreatInquiryOutput> {
  return naturalLanguageThreatInquiryFlow(input);
}

const prompt = ai.definePrompt({
  name: 'naturalLanguageThreatInquiryPrompt',
  input: { schema: NaturalLanguageThreatInquiryInputSchema },
  output: { schema: NaturalLanguageThreatInquiryOutputSchema },
  prompt: `You are an expert cybersecurity analyst AI named AegisAI. Your role is to provide detailed, context-aware explanations and insights to security analysts regarding cybersecurity alerts, system vulnerabilities, and general threat inquiries.

When providing an answer, ensure it is comprehensive, accurate, and actionable. If context is provided, use it heavily to inform your answer. If no context is provided, answer the question based on general cybersecurity knowledge.

Here is the user's question:
Question: {{{question}}}

{{#if context}}
Here is the relevant context:
Context: {{{context}}}
{{/if}}

Provide your detailed explanation and insight in the 'answer' field of the JSON output.`,
});

const naturalLanguageThreatInquiryFlow = ai.defineFlow(
  {
    name: 'naturalLanguageThreatInquiryFlow',
    inputSchema: NaturalLanguageThreatInquiryInputSchema,
    outputSchema: NaturalLanguageThreatInquiryOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);
