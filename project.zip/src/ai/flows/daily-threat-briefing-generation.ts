'use server';
/**
 * @fileOverview This file implements the daily threat briefing generation flow.
 *
 * - generateDailyThreatBriefing - A function that generates a concise daily threat briefing.
 * - DailyThreatBriefingInput - The input type for the generateDailyThreatBriefing function.
 * - DailyThreatBriefingOutput - The return type for the generateDailyThreatBriefing function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const DailyThreatBriefingInputSchema = z.object({
  securityLogSummary: z
    .string()
    .describe('A summary of critical security log events from the day.'),
  anomalyDetections: z
    .array(z.string())
    .describe('A list of detected anomalous behaviors or potential threats.'),
  threatIntelligenceUpdates: z
    .array(z.string())
    .describe('A list of recent threat intelligence updates or emerging vulnerabilities.'),
});
export type DailyThreatBriefingInput = z.infer<typeof DailyThreatBriefingInputSchema>;

const DailyThreatBriefingOutputSchema = z.object({
  briefing: z.string().describe('The concise daily threat briefing.'),
});
export type DailyThreatBriefingOutput = z.infer<typeof DailyThreatBriefingOutputSchema>;

export async function generateDailyThreatBriefing(
  input: DailyThreatBriefingInput
): Promise<DailyThreatBriefingOutput> {
  return dailyThreatBriefingFlow(input);
}

const prompt = ai.definePrompt({
  name: 'dailyThreatBriefingPrompt',
  input: {schema: DailyThreatBriefingInputSchema},
  output: {schema: DailyThreatBriefingOutputSchema},
  prompt: `You are an AI cybersecurity agent named AegisAI. Your task is to generate a concise daily threat briefing for a security manager.
The briefing should summarize critical risks, emerging vulnerabilities, and their potential impact based on the provided data.
Keep it professional, clear, and actionable.

Here's the data for today's briefing:

Security Log Summary:
{{{securityLogSummary}}}

Detected Anomalies:
{{#if anomalyDetections}}
{{#each anomalyDetections}}- {{{this}}}
{{/each}}
{{else}}No significant anomalies detected.
{{/if}}

Threat Intelligence Updates:
{{#if threatIntelligenceUpdates}}
{{#each threatIntelligenceUpdates}}- {{{this}}}
{{/each}}
{{else}}No new critical threat intelligence updates.
{{/if}}

Please provide a concise daily threat briefing.`,
});

const dailyThreatBriefingFlow = ai.defineFlow(
  {
    name: 'dailyThreatBriefingFlow',
    inputSchema: DailyThreatBriefingInputSchema,
    outputSchema: DailyThreatBriefingOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
