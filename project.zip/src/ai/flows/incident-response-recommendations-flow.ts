'use server';
/**
 * @fileOverview This file implements a Genkit flow for generating incident response recommendations.
 *
 * - incidentResponseRecommendations - A function that provides prioritized incident response actions and mitigation strategies.
 * - IncidentResponseRecommendationsInput - The input type for the incidentResponseRecommendations function.
 * - IncidentResponseRecommendationsOutput - The return type for the incidentResponseRecommendations function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const IncidentResponseRecommendationsInputSchema = z.object({
  incidentType: z
    .string()
    .describe(
      'The type of cybersecurity incident (e.g., "DDoS attack", "Malware infection", "Phishing attempt").'
    ),
  description: z
    .string()
    .describe(
      'A detailed description of the incident, including any known indicators of compromise.'
    ),
  affectedSystems: z
    .array(z.string())
    .describe(
      'A list of systems or assets affected by the incident (e.g., "Web Server 1", "Database Server", "User Workstation Network").'
    ),
  severity: z
    .enum(['Low', 'Medium', 'High', 'Critical'])
    .describe('The assessed severity of the incident.'),
});
export type IncidentResponseRecommendationsInput = z.infer<
  typeof IncidentResponseRecommendationsInputSchema
>;

const IncidentResponseRecommendationsOutputSchema = z.object({
  recommendations: z
    .array(
      z.object({
        action: z
          .string()
          .describe('The specific immediate response action to be taken.'),
        priority: z
          .enum(['Critical', 'High', 'Medium', 'Low'])
          .describe('The priority level for this action.'),
        strategy: z
          .string()
          .describe(
            'The underlying mitigation strategy this action addresses (e.g., Containment, Eradication, Recovery, Analysis).'
          ),
        rationale: z
          .string()
          .describe(
            'A brief explanation of why this action is recommended and its expected impact.'
          ),
      })
    )
    .describe(
      'A prioritized list of recommended immediate response actions and mitigation strategies.'
    ),
});
export type IncidentResponseRecommendationsOutput = z.infer<
  typeof IncidentResponseRecommendationsOutputSchema
>;

export async function incidentResponseRecommendations(
  input: IncidentResponseRecommendationsInput
): Promise<IncidentResponseRecommendationsOutput> {
  return incidentResponseRecommendationsFlow(input);
}

const incidentResponsePrompt = ai.definePrompt({
  name: 'incidentResponseRecommendationsPrompt',
  input: { schema: IncidentResponseRecommendationsInputSchema },
  output: { schema: IncidentResponseRecommendationsOutputSchema },
  prompt: `You are a highly experienced and certified cybersecurity incident response expert. Your task is to provide a prioritized list of immediate response actions and mitigation strategies for a detected cybersecurity incident.

Consider the following details:
Incident Type: {{{incidentType}}}
Description: {{{description}}}
Affected Systems: {{#each affectedSystems}}- {{{this}}}
{{/each}}
Severity: {{{severity}}}

Based on these details, generate a JSON object containing a prioritized list of actions. Each action should include:
1.  'action': A concise, actionable step.
2.  'priority': The urgency of the action (Critical, High, Medium, Low).
3.  'strategy': The incident response phase or strategy it belongs to (e.g., Containment, Eradication, Recovery, Analysis).
4.  'rationale': A brief explanation of why this action is important.`,
});

const incidentResponseRecommendationsFlow = ai.defineFlow(
  {
    name: 'incidentResponseRecommendationsFlow',
    inputSchema: IncidentResponseRecommendationsInputSchema,
    outputSchema: IncidentResponseRecommendationsOutputSchema,
  },
  async (input) => {
    const { output } = await incidentResponsePrompt(input);
    return output!;
  }
);
