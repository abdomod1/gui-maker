'use server';
/**
 * @fileOverview This file implements a Genkit flow for cybersecurity threat detection and anomaly flagging.
 * It analyzes security logs and network activity to identify potential threats and unusual patterns.
 *
 * - threatDetectionAndAnomalyFlagging - The main function to trigger the threat detection process.
 * - ThreatDetectionAndAnomalyFlaggingInput - The input type for the threatDetectionAndAnomalyFlagging function.
 * - ThreatDetectionAndAnomalyFlaggingOutput - The return type for the threatDetectionAndAnomalyFlagging function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const ThreatDetectionAndAnomalyFlaggingInputSchema = z.object({
  securityLogs: z
    .array(z.string())
    .describe('A list of recent security log entries for analysis. Each entry should be a single log line.'),
  networkActivity: z
    .array(z.string())
    .describe('A list of recent network activity records, e.g., connection attempts, data transfers, etc. Each entry should be a single activity record.'),
});
export type ThreatDetectionAndAnomalyFlaggingInput = z.infer<
  typeof ThreatDetectionAndAnomalyFlaggingInputSchema
>;

const ThreatDetectionAndAnomalyFlaggingOutputSchema = z.object({
  isAnomaly: z
    .boolean()
    .describe('True if an anomaly or potential threat was detected, false otherwise.'),
  threatLevel: z
    .enum(['None', 'Low', 'Medium', 'High', 'Critical'])
    .describe('The severity of the detected threat or anomaly. Should be "None" if no anomaly is detected.'),
  detectedThreats: z
    .array(z.string())
    .describe('A list of specific threats or suspicious activities identified. Should be empty if no threats are detected.'),
  anomalyDetails: z
    .string()
    .describe('Detailed explanation of the detected anomaly or threat, including its potential impact and reasoning. Should provide a summary of analysis if no anomaly is detected.'),
});
export type ThreatDetectionAndAnomalyFlaggingOutput = z.infer<
  typeof ThreatDetectionAndAnomalyFlaggingOutputSchema
>;

const threatDetectionAndAnomalyPrompt = ai.definePrompt({
  name: 'threatDetectionAndAnomalyPrompt',
  input: { schema: ThreatDetectionAndAnomalyFlaggingInputSchema },
  output: { schema: ThreatDetectionAndAnomalyFlaggingOutputSchema },
  prompt: `You are an expert cybersecurity analyst for AegisAI, specializing in threat identification and anomaly detection. Your task is to analyze provided security logs and network activity patterns to identify any anomalous behaviors or potential cybersecurity threats.

Based on the analysis, you must determine if there is an anomaly or threat present, assign a threat level, list any specific detected threats, and provide a detailed explanation of your findings.

If no anomalies or threats are detected, set 'isAnomaly' to false, 'threatLevel' to 'None', 'detectedThreats' to an empty array, and provide a brief summary of your analysis in 'anomalyDetails'.

---
Security Logs:
{{#if securityLogs}}
{{#each securityLogs}}
- {{{this}}}
{{/each}}
{{else}}
No security logs provided.
{{/if}}

---
Network Activity:
{{#if networkActivity}}
{{#each networkActivity}}
- {{{this}}}
{{/each}}
{{else}}
No network activity provided.
{{/if}}

---
Analyze the provided information and respond ONLY in the JSON format specified by the output schema, with no additional text or explanation. Ensure all fields are populated based on your findings.`,
});

const threatDetectionAndAnomalyFlaggingFlow = ai.defineFlow(
  {
    name: 'threatDetectionAndAnomalyFlaggingFlow',
    inputSchema: ThreatDetectionAndAnomalyFlaggingInputSchema,
    outputSchema: ThreatDetectionAndAnomalyFlaggingOutputSchema,
  },
  async (input) => {
    const { output } = await threatDetectionAndAnomalyPrompt(input);
    return output!;
  },
);

export async function threatDetectionAndAnomalyFlagging(
  input: ThreatDetectionAndAnomalyFlaggingInput,
): Promise<ThreatDetectionAndAnomalyFlaggingOutput> {
  return threatDetectionAndAnomalyFlaggingFlow(input);
}
