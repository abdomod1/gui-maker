import { config } from 'dotenv';
config();

import '@/ai/flows/natural-language-threat-inquiry.ts';
import '@/ai/flows/threat-detection-and-anomaly-flagging.ts';
import '@/ai/flows/daily-threat-briefing-generation.ts';
import '@/ai/flows/incident-response-recommendations-flow.ts';