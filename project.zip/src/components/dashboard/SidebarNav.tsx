"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { 
  ShieldAlert, 
  LayoutDashboard, 
  FileText, 
  MessageSquare, 
  Settings, 
  Activity, 
  Zap,
  ChevronRight
} from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { name: "Dashboard", icon: LayoutDashboard, href: "/" },
  { name: "Threat Analysis", icon: Activity, href: "/threats" },
  { name: "Daily Briefings", icon: FileText, href: "/briefings" },
  { name: "Aegis Assistant", icon: MessageSquare, href: "/assistant" },
  { name: "Response Tool", icon: Zap, href: "/response" },
];

export function SidebarNav() {
  const pathname = usePathname();

  return (
    <div className="flex flex-col h-full bg-sidebar border-r border-sidebar-border">
      <div className="p-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center glow-primary">
            <ShieldAlert className="text-primary-foreground w-6 h-6" />
          </div>
          <div>
            <h1 className="font-headline font-bold text-xl tracking-tight">AegisAI</h1>
            <p className="text-[10px] text-muted-foreground uppercase tracking-widest">Active Protection</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 px-4 space-y-2 mt-4">
        {navItems.map((item) => {
          const isActive = pathname === item.href;
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 group relative",
                isActive 
                  ? "bg-primary text-primary-foreground font-medium glow-primary" 
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              )}
            >
              <item.icon className={cn("w-5 h-5", isActive ? "" : "group-hover:text-primary transition-colors")} />
              <span className="text-sm">{item.name}</span>
              {isActive && (
                <div className="absolute right-3">
                  <ChevronRight className="w-4 h-4 opacity-50" />
                </div>
              )}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-sidebar-border">
        <Link
          href="/settings"
          className="flex items-center gap-3 px-4 py-3 rounded-lg text-sidebar-foreground hover:bg-sidebar-accent transition-all duration-200"
        >
          <Settings className="w-5 h-5" />
          <span className="text-sm font-medium">System Settings</span>
        </Link>
        <div className="mt-4 p-4 rounded-xl bg-primary/5 border border-primary/20">
          <p className="text-[10px] font-bold text-primary uppercase mb-1">Node Security</p>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            <span className="text-[11px] text-muted-foreground font-medium">All systems operational</span>
          </div>
        </div>
      </div>
    </div>
  );
}