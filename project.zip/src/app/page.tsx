"use client";

import { SidebarNav } from "@/components/dashboard/SidebarNav";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Shield, 
  AlertTriangle, 
  Activity, 
  Eye, 
  ArrowUpRight, 
  Clock,
  TrendingUp,
  Globe
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from "recharts";
import { mockAnomalies } from "@/app/lib/mock-data";

const data = [
  { name: "00:00", threats: 12, anomalies: 4 },
  { name: "04:00", threats: 8, anomalies: 2 },
  { name: "08:00", threats: 24, anomalies: 7 },
  { name: "12:00", threats: 18, anomalies: 5 },
  { name: "16:00", threats: 32, anomalies: 12 },
  { name: "20:00", threats: 28, anomalies: 9 },
  { name: "23:59", threats: 15, anomalies: 6 },
];

export default function DashboardPage() {
  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <div className="w-64 flex-shrink-0">
        <SidebarNav />
      </div>
      
      <main className="flex-1 overflow-y-auto p-8 space-y-8">
        <header className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-headline font-bold text-foreground">Security Overview</h1>
            <p className="text-muted-foreground">Welcome back, Agent. Here's your node's real-time posture.</p>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" className="border-border">
              <Clock className="w-4 h-4 mr-2" />
              History
            </Button>
            <Button className="bg-primary text-primary-foreground glow-primary">
              Run Scan
            </Button>
          </div>
        </header>

        {/* KPI Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="glass-panel">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium">Security Score</CardTitle>
              <Shield className="w-4 h-4 text-primary" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">94%</div>
              <p className="text-xs text-muted-foreground">+2% from last audit</p>
              <div className="mt-4 h-1.5 w-full bg-secondary rounded-full overflow-hidden">
                <div className="h-full bg-primary" style={{ width: "94%" }} />
              </div>
            </CardContent>
          </Card>

          <Card className="glass-panel">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium">Active Alerts</CardTitle>
              <AlertTriangle className="w-4 h-4 text-destructive" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">14</div>
              <p className="text-xs text-muted-foreground">3 critical alerts pending</p>
              <div className="mt-4 flex gap-1">
                <div className="h-1.5 flex-1 bg-destructive rounded-full" />
                <div className="h-1.5 flex-1 bg-destructive rounded-full opacity-50" />
                <div className="h-1.5 flex-1 bg-secondary rounded-full" />
              </div>
            </CardContent>
          </Card>

          <Card className="glass-panel">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium">Traffic (24h)</CardTitle>
              <Globe className="w-4 h-4 text-accent" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1.2 TB</div>
              <p className="text-xs text-muted-foreground">+12% traffic volume</p>
              <div className="mt-4 h-1.5 w-full bg-secondary rounded-full overflow-hidden">
                <div className="h-full bg-accent" style={{ width: "65%" }} />
              </div>
            </CardContent>
          </Card>

          <Card className="glass-panel">
            <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
              <CardTitle className="text-sm font-medium">Threat Blocks</CardTitle>
              <Activity className="w-4 h-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">482</div>
              <p className="text-xs text-muted-foreground">Successful interventions</p>
              <div className="mt-4 h-1.5 w-full bg-secondary rounded-full overflow-hidden">
                <div className="h-full bg-green-400" style={{ width: "88%" }} />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Charts and Lists */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 glass-panel">
            <CardHeader>
              <CardTitle className="text-lg font-headline flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                Threat Detection Trends
              </CardTitle>
              <CardDescription>Visual analysis of blocked threats and anomalies identified by AegisAI.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data}>
                    <defs>
                      <linearGradient id="colorThreats" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorAnomalies" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="hsl(var(--accent))" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="hsl(var(--accent))" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsla(var(--border), 0.3)" />
                    <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: "hsl(var(--card))", 
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px"
                      }} 
                    />
                    <Area type="monotone" dataKey="threats" stroke="hsl(var(--primary))" fillOpacity={1} fill="url(#colorThreats)" />
                    <Area type="monotone" dataKey="anomalies" stroke="hsl(var(--accent))" fillOpacity={1} fill="url(#colorAnomalies)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card className="glass-panel">
            <CardHeader>
              <CardTitle className="text-lg font-headline">Recent Anomalies</CardTitle>
              <CardDescription>Top detected unusual behaviors.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {mockAnomalies.map((anomaly) => (
                <div key={anomaly.id} className="p-3 rounded-lg border border-border/50 hover:bg-white/5 transition-colors cursor-pointer group">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-bold font-headline">{anomaly.type}</span>
                    <Badge variant={anomaly.severity === "Critical" ? "destructive" : anomaly.severity === "High" ? "default" : "secondary"}>
                      {anomaly.severity}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-1 mb-2">{anomaly.description}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-muted-foreground font-mono">{anomaly.id}</span>
                    <span className="text-[10px] text-muted-foreground flex items-center gap-1 group-hover:text-primary transition-colors">
                      View Report <ArrowUpRight className="w-2.5 h-2.5" />
                    </span>
                  </div>
                </div>
              ))}
              <Button variant="ghost" className="w-full text-xs hover:bg-primary/10">View All Detections</Button>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}