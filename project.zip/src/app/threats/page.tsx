"use client";

import { useState } from "react";
import { SidebarNav } from "@/components/dashboard/SidebarNav";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Activity, 
  Search, 
  Terminal, 
  AlertCircle, 
  CheckCircle2, 
  ChevronRight,
  ShieldAlert,
  Zap,
  RefreshCw,
  Loader2
} from "lucide-react";
import { threatDetectionAndAnomalyFlagging, type ThreatDetectionAndAnomalyFlaggingOutput } from "@/ai/flows/threat-detection-and-anomaly-flagging";
import { mockSecurityLogs, mockNetworkActivity } from "@/app/lib/mock-data";

export default function ThreatsPage() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<ThreatDetectionAndAnomalyFlaggingOutput | null>(null);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    try {
      const result = await threatDetectionAndAnomalyFlagging({
        securityLogs: mockSecurityLogs,
        networkActivity: mockNetworkActivity,
      });
      setAnalysisResult(result);
    } catch (error) {
      console.error("Analysis failed:", error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <div className="w-64 flex-shrink-0">
        <SidebarNav />
      </div>
      
      <main className="flex-1 overflow-y-auto p-8 space-y-8">
        <header className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-headline font-bold text-foreground">Threat Analysis</h1>
            <p className="text-muted-foreground">Continuously monitoring for anomalies in system logs and network streams.</p>
          </div>
          <Button 
            onClick={handleAnalyze} 
            disabled={isAnalyzing}
            className="bg-primary text-primary-foreground glow-primary min-w-[140px]"
          >
            {isAnalyzing ? (
              <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Analyzing...</>
            ) : (
              <><Zap className="w-4 h-4 mr-2" /> Start Analysis</>
            )}
          </Button>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Data Sources */}
          <div className="space-y-6">
            <Card className="glass-panel">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-headline flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-accent" />
                  Live Security Logs
                </CardTitle>
                <CardDescription>Incoming authentication and system events.</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[250px] rounded-md border border-border/50 bg-black/30 p-4">
                  <div className="space-y-2 font-code text-xs">
                    {mockSecurityLogs.map((log, i) => (
                      <div key={i} className="text-muted-foreground border-b border-border/10 pb-1">
                        <span className="text-accent/70">{">"}</span> {log}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            <Card className="glass-panel">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-headline flex items-center gap-2">
                  <Activity className="w-4 h-4 text-primary" />
                  Network Activity Monitor
                </CardTitle>
                <CardDescription>Real-time traffic flow patterns.</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[250px] rounded-md border border-border/50 bg-black/30 p-4">
                  <div className="space-y-2 font-code text-xs">
                    {mockNetworkActivity.map((activity, i) => (
                      <div key={i} className="text-muted-foreground border-b border-border/10 pb-1">
                        <span className="text-primary/70">{">"}</span> {activity}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Analysis Result */}
          <div className="space-y-6">
            <Card className={cn(
              "glass-panel border-l-4 transition-all duration-500 min-h-full",
              analysisResult?.isAnomaly ? "border-l-destructive" : analysisResult ? "border-l-green-500" : "border-l-primary"
            )}>
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <CardTitle className="text-lg font-headline flex items-center gap-2">
                    <ShieldAlert className="w-5 h-5" />
                    AegisAI Analysis Engine
                  </CardTitle>
                  {analysisResult && (
                    <Badge variant={analysisResult.isAnomaly ? "destructive" : "default"} className="animate-in fade-in zoom-in duration-300">
                      {analysisResult.threatLevel} Threat
                    </Badge>
                  )}
                </div>
                <CardDescription>
                  Generative AI processing of security telemetry.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {!analysisResult && !isAnalyzing && (
                  <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
                    <RefreshCw className="w-12 h-12 mb-4 opacity-20" />
                    <p>Analysis required to identify potential risks.</p>
                    <p className="text-xs">Click 'Start Analysis' to process current logs.</p>
                  </div>
                )}

                {isAnalyzing && (
                  <div className="flex flex-col items-center justify-center py-12 text-center text-primary">
                    <Loader2 className="w-12 h-12 mb-4 animate-spin opacity-50" />
                    <p className="animate-pulse">Synthesizing log patterns...</p>
                    <p className="text-xs text-muted-foreground">Cross-referencing global threat signatures</p>
                  </div>
                )}

                {analysisResult && (
                  <div className="animate-in slide-in-from-bottom-2 space-y-6">
                    <div>
                      <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3">Detection Summary</h4>
                      <p className="text-sm leading-relaxed text-foreground bg-white/5 p-4 rounded-lg border border-white/5">
                        {analysisResult.anomalyDetails}
                      </p>
                    </div>

                    {analysisResult.detectedThreats.length > 0 && (
                      <div>
                        <h4 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3">Specific Risks Identified</h4>
                        <div className="space-y-2">
                          {analysisResult.detectedThreats.map((threat, idx) => (
                            <div key={idx} className="flex items-center gap-2 text-sm text-destructive font-medium bg-destructive/10 p-2 px-3 rounded-md border border-destructive/20">
                              <AlertCircle className="w-4 h-4" />
                              {threat}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {!analysisResult.isAnomaly && (
                      <div className="flex items-center gap-2 text-sm text-green-400 font-medium bg-green-400/10 p-3 rounded-md border border-green-400/20">
                        <CheckCircle2 className="w-4 h-4" />
                        System integrity validated. No critical anomalies found.
                      </div>
                    )}

                    <div className="pt-4 flex gap-3">
                      <Button variant="outline" size="sm" className="w-full">Export Report</Button>
                      <Button size="sm" className="w-full bg-primary text-primary-foreground">Mitigate All</Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}