"use client";

import { useState } from "react";
import { SidebarNav } from "@/components/dashboard/SidebarNav";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Zap, 
  ShieldAlert, 
  Server, 
  ArrowRight,
  ShieldCheck,
  AlertCircle,
  Loader2,
  Trash2,
  Plus
} from "lucide-react";
import { incidentResponseRecommendations, type IncidentResponseRecommendationsOutput } from "@/ai/flows/incident-response-recommendations-flow";
import { cn } from "@/lib/utils";

export default function ResponsePage() {
  const [incidentType, setIncidentType] = useState("DDoS Attack Pattern");
  const [description, setDescription] = useState("Sudden spike in inbound traffic on port 443 originating from several botnet-associated IP ranges.");
  const [severity, setSeverity] = useState<"Low" | "Medium" | "High" | "Critical">("High");
  const [affectedSystems, setAffectedSystems] = useState<string[]>(["Main Web Load Balancer", "Cloudflare Edge Subnet"]);
  const [newSystem, setNewSystem] = useState("");
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [recommendations, setRecommendations] = useState<IncidentResponseRecommendationsOutput | null>(null);

  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      const result = await incidentResponseRecommendations({
        incidentType,
        description,
        severity,
        affectedSystems,
      });
      setRecommendations(result);
    } catch (error) {
      console.error("Failed to generate recommendations:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  const addSystem = () => {
    if (newSystem.trim()) {
      setAffectedSystems([...affectedSystems, newSystem.trim()]);
      setNewSystem("");
    }
  };

  const removeSystem = (index: number) => {
    setAffectedSystems(affectedSystems.filter((_, i) => i !== index));
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <div className="w-64 flex-shrink-0">
        <SidebarNav />
      </div>
      
      <main className="flex-1 overflow-y-auto p-8 space-y-8">
        <header>
          <h1 className="text-3xl font-headline font-bold text-foreground">Incident Response Tool</h1>
          <p className="text-muted-foreground">Prioritized immediate actions and mitigation strategies for detected threats.</p>
        </header>

        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
          {/* Incident Input Form */}
          <div className="xl:col-span-5 space-y-6">
            <Card className="glass-panel">
              <CardHeader>
                <CardTitle className="text-lg font-headline">Incident Parameters</CardTitle>
                <CardDescription>Detail the detected threat for AI-assisted strategy generation.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Incident Type</label>
                  <Input 
                    value={incidentType} 
                    onChange={(e) => setIncidentType(e.target.value)}
                    placeholder="e.g., SQL Injection, Ransomware" 
                    className="bg-black/20 border-border"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Severity Level</label>
                  <div className="flex gap-2">
                    {["Low", "Medium", "High", "Critical"].map((level) => (
                      <Button
                        key={level}
                        variant={severity === level ? "default" : "outline"}
                        size="sm"
                        className={cn(
                          "flex-1 text-xs",
                          severity === level && level === "Critical" ? "bg-destructive text-destructive-foreground" : ""
                        )}
                        onClick={() => setSeverity(level as any)}
                      >
                        {level}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Full Description</label>
                  <Textarea 
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Provide detailed indicators of compromise..." 
                    className="bg-black/20 border-border min-h-[100px]"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Affected Systems</label>
                  <div className="flex gap-2 mb-2">
                    <Input 
                      value={newSystem}
                      onChange={(e) => setNewSystem(e.target.value)}
                      placeholder="e.g., Web Server 01" 
                      className="bg-black/20 border-border"
                      onKeyDown={(e) => e.key === 'Enter' && addSystem()}
                    />
                    <Button variant="secondary" onClick={addSystem} size="icon"><Plus className="w-4 h-4" /></Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {affectedSystems.map((sys, idx) => (
                      <Badge key={idx} variant="outline" className="flex items-center gap-1 py-1 pl-3 bg-white/5 border-white/10">
                        {sys}
                        <button onClick={() => removeSystem(idx)} className="hover:text-destructive p-1">
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>

                <Button 
                  onClick={handleGenerate} 
                  disabled={isGenerating}
                  className="w-full bg-primary text-primary-foreground mt-4 glow-primary"
                >
                  {isGenerating ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Simulating Response...</>
                  ) : (
                    <><Zap className="w-4 h-4 mr-2" /> Generate Response Strategy</>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Recommendations Output */}
          <div className="xl:col-span-7 space-y-6">
            {!recommendations && !isGenerating ? (
              <div className="h-full min-h-[400px] flex flex-col items-center justify-center border-2 border-dashed border-border rounded-xl text-muted-foreground opacity-50">
                <ShieldCheck className="w-16 h-16 mb-4" />
                <p className="font-headline text-lg">Response Strategy Output</p>
                <p className="text-sm">Enter incident details and click generate to receive prioritized actions.</p>
              </div>
            ) : isGenerating ? (
              <div className="h-full min-h-[400px] flex flex-col items-center justify-center glass-panel rounded-xl text-primary gap-4">
                <Loader2 className="w-12 h-12 animate-spin" />
                <div className="text-center">
                  <p className="font-headline text-lg">AegisAI is consulting threat patterns...</p>
                  <p className="text-xs text-muted-foreground">Modeling containment and eradication strategies</p>
                </div>
              </div>
            ) : (
              <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-500">
                <div className="flex items-center justify-between px-2">
                  <h3 className="font-headline font-bold text-xl flex items-center gap-2">
                    <Zap className="text-primary w-5 h-5" /> 
                    Immediate Recommendations
                  </h3>
                  <Badge className="bg-primary/20 text-primary border-primary/30">AI Generated</Badge>
                </div>
                
                {recommendations?.recommendations.map((rec, i) => (
                  <Card key={i} className="glass-panel hover:border-primary/50 transition-colors">
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between gap-4 mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-mono text-muted-foreground">ACTION #{i + 1}</span>
                            <Badge variant={rec.priority === "Critical" ? "destructive" : "default"} className="text-[10px] h-4">
                              {rec.priority}
                            </Badge>
                          </div>
                          <h4 className="font-headline font-bold text-lg">{rec.action}</h4>
                        </div>
                        <Badge variant="outline" className="bg-accent/5 border-accent/20 text-accent uppercase text-[10px]">
                          {rec.strategy}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground bg-black/20 p-3 rounded-md border border-white/5">
                        <span className="font-bold text-foreground text-xs block mb-1">RATIONALE:</span>
                        {rec.rationale}
                      </p>
                      <div className="mt-4 flex justify-end">
                        <Button size="sm" variant="ghost" className="text-xs hover:text-primary">
                          Mark as Implemented <ShieldCheck className="w-3.5 h-3.5 ml-2" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                <div className="flex gap-4 pt-4">
                  <Button variant="outline" className="flex-1">Export Action Plan</Button>
                  <Button className="flex-1 bg-primary text-primary-foreground">Notify Incident Team</Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}