"use client";

import { useState, useRef, useEffect } from "react";
import { SidebarNav } from "@/components/dashboard/SidebarNav";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Send, 
  ShieldAlert, 
  User, 
  Bot, 
  Sparkles, 
  Plus, 
  Trash2, 
  Search,
  MessageSquare,
  Loader2
} from "lucide-react";
import { naturalLanguageThreatInquiry } from "@/ai/flows/natural-language-threat-inquiry";
import { cn } from "@/lib/utils";

type Message = {
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
};

export default function AssistantPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "Hello Agent. I am AegisAI Assistant. You can ask me about specific alerts, system vulnerabilities, or general threat intelligence. How can I assist you today?",
      timestamp: new Date(),
    }
  ]);
  const [input, setInput] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isProcessing) return;

    const userMessage: Message = {
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsProcessing(true);

    try {
      const result = await naturalLanguageThreatInquiry({
        question: input,
        context: "Current system status: Online. Recent alerts: Brute force attempts from 192.168.1.45. Security score: 94%.",
      });

      const assistantMessage: Message = {
        role: "assistant",
        content: result.answer,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      console.error("Inquiry failed:", error);
      const errorMessage: Message = {
        role: "assistant",
        content: "I'm sorry, I encountered an error while processing your inquiry. Please try again or check the system logs.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <div className="w-64 flex-shrink-0">
        <SidebarNav />
      </div>
      
      <main className="flex-1 flex flex-col h-full">
        {/* Chat Header */}
        <header className="p-6 border-b border-border/50 bg-card/30 backdrop-blur-sm flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center border border-primary/30 glow-primary">
              <Bot className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h2 className="font-headline font-bold text-lg">Aegis Intelligence Hub</h2>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                <span className="text-[10px] text-muted-foreground font-medium uppercase tracking-widest">Cognitive Core Online</span>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="ghost" size="icon" className="hover:text-primary"><Plus className="w-4 h-4" /></Button>
            <Button variant="ghost" size="icon" className="hover:text-destructive"><Trash2 className="w-4 h-4" /></Button>
          </div>
        </header>

        {/* Chat Area */}
        <ScrollArea className="flex-1 p-6 overflow-y-auto" ref={scrollRef}>
          <div className="max-w-3xl mx-auto space-y-8 pb-10">
            {messages.map((msg, i) => (
              <div key={i} className={cn(
                "flex gap-4 animate-in fade-in slide-in-from-bottom-2 duration-300",
                msg.role === "user" ? "flex-row-reverse" : ""
              )}>
                <Avatar className={cn(
                  "w-10 h-10 border",
                  msg.role === "assistant" ? "border-primary/50 bg-primary/10" : "border-accent/50 bg-accent/10"
                )}>
                  <AvatarFallback className="bg-transparent">
                    {msg.role === "assistant" ? <Bot className="w-5 h-5 text-primary" /> : <User className="w-5 h-5 text-accent" />}
                  </AvatarFallback>
                </Avatar>
                
                <div className={cn(
                  "flex-1 space-y-2",
                  msg.role === "user" ? "text-right" : ""
                )}>
                  <div className="flex items-center gap-2 mb-1 justify-end flex-row-reverse">
                    <span className="text-xs font-bold font-headline uppercase tracking-wider text-muted-foreground">
                      {msg.role === "assistant" ? "AegisAI" : "Security Analyst"}
                    </span>
                    <span className="text-[10px] text-muted-foreground font-mono">
                      {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  
                  <div className={cn(
                    "p-4 rounded-2xl text-sm leading-relaxed",
                    msg.role === "assistant" 
                      ? "bg-card border border-border text-foreground shadow-lg" 
                      : "bg-primary text-primary-foreground font-medium glow-primary inline-block text-left"
                  )}>
                    {msg.content}
                  </div>
                </div>
              </div>
            ))}
            
            {isProcessing && (
              <div className="flex gap-4 animate-in fade-in duration-300">
                <Avatar className="w-10 h-10 border border-primary/50 bg-primary/10">
                  <AvatarFallback className="bg-transparent">
                    <Bot className="w-5 h-5 text-primary" />
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-2">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold font-headline uppercase tracking-wider text-primary">AegisAI Thinking</span>
                  </div>
                  <div className="bg-card border border-border p-4 rounded-2xl flex items-center gap-3">
                    <Loader2 className="w-4 h-4 animate-spin text-primary" />
                    <span className="text-xs text-muted-foreground italic">Consulting local threat databases...</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="p-6 border-t border-border/50 bg-card/30 backdrop-blur-sm">
          <div className="max-w-3xl mx-auto">
            <div className="relative group">
              <Input
                placeholder="Query system vulnerability status or analyze a recent alert..."
                className="pr-24 h-14 bg-black/40 border-border focus:border-primary/50 transition-all rounded-xl glow-primary"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              />
              <div className="absolute right-2 top-2 bottom-2 flex gap-2">
                <Button 
                  size="sm" 
                  className="bg-primary text-primary-foreground px-4 rounded-lg h-full"
                  onClick={handleSend}
                  disabled={isProcessing || !input.trim()}
                >
                  <Send className="w-4 h-4 mr-2" />
                  Send
                </Button>
              </div>
            </div>
            <div className="mt-3 flex gap-4 justify-center">
              {["Analyze latest logs", "Vulnerability scan status", "Explain SQL Injection risk"].map((tag) => (
                <button 
                  key={tag}
                  onClick={() => setInput(tag)}
                  className="text-[10px] uppercase font-bold tracking-widest text-muted-foreground hover:text-primary transition-colors flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3" />
                  {tag}
                </button>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}