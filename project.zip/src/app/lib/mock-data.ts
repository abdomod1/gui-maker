export const mockSecurityLogs = [
  "2023-10-27 10:15:32 - SRC: 192.168.1.45 - DST: 10.0.0.5 - PORT: 22 - ACTION: REJECT - REASON: MULTIPLE_FAILED_LOGINS",
  "2023-10-27 10:16:05 - SRC: 172.16.0.12 - DST: INTERNAL_DB - PORT: 5432 - ACTION: ALLOW - REASON: AUTHORIZED_QUERY",
  "2023-10-27 10:17:44 - SRC: 192.168.1.102 - DST: EXTERNAL_IP_203.0.113.4 - PORT: 443 - ACTION: ALLOW - REASON: HTTPS_TRAFFIC",
  "2023-10-27 10:18:12 - SRC: UNKNOWN_BOT - DST: WEB_SERVER_1 - PORT: 80 - ACTION: REJECT - REASON: SQL_INJECTION_PATTERN",
  "2023-10-27 10:20:55 - SRC: ADMIN_WS - DST: CORE_ROUTER - PORT: 22 - ACTION: ALLOW - REASON: SSH_ADMIN_SESSION",
  "2023-10-27 10:22:11 - SRC: 192.168.1.200 - DST: MAIL_SERVER - PORT: 25 - ACTION: REJECT - REASON: SPAM_SIGNATURE",
];

export const mockNetworkActivity = [
  "Connection attempt from 185.123.4.5 to port 3389 (RDP) - BLOCKED",
  "Data transfer of 2.4GB from DB_MASTER to BACKUP_SVR - COMPLETED",
  "High frequency DNS requests from 192.168.1.88 - MONITORING",
  "New device joined subnet 192.168.10.0/24 - IDENTIFIED: IOT_DEVICE_04",
  "Inbound traffic spike detected on port 80 - DDoS mitigation active",
];

export const mockAnomalies = [
  {
    id: "ANOM-001",
    type: "Brute Force Attempt",
    severity: "High",
    status: "Active",
    timestamp: "2 minutes ago",
    description: "Multiple failed SSH login attempts detected from a single external IP targeting critical infrastructure.",
  },
  {
    id: "ANOM-002",
    type: "Unusual Data Egress",
    severity: "Medium",
    status: "Investigating",
    timestamp: "15 minutes ago",
    description: "Workstation 14 exporting 500MB of encrypted data to an unknown cloud storage endpoint.",
  },
  {
    id: "ANOM-003",
    type: "Lateral Movement Pattern",
    severity: "Critical",
    status: "Flagged",
    timestamp: "1 hour ago",
    description: "Account 'Service_Proc' attempting to access multiple database shards without prior history.",
  }
];

export const mockThreatIntelligence = [
  "New Zero-Day vulnerability (CVE-2023-45678) affecting popular web server frameworks.",
  "Rise in targeted phishing campaigns using deepfake voice technology.",
  "New malware variant 'StormBringer' observed in the financial sector.",
];