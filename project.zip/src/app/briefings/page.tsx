"use client";

import { useState, useEffect } from "react";
import { SidebarNav } from "@/components/dashboard/SidebarNav";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  Sparkles, 
  Calendar, 
  Share2, 
  Download,
  Printer,
  ChevronRight,
  Loader2
} from "lucide-react";
import { generateDailyThreatBriefing } from "@/ai/flows/daily-threat-briefing-generation";
import { mockThreatIntelligence, mockAnomalies } from "@/app/lib/mock-data";

export default function BriefingPage() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [briefing, setBriefing] = useState<string | null>(null);

  const generateBriefing = async () => {
    setIsGenerating(true);
    try {
      const result = await generateDailyThreatBriefing({
        securityLogSummary: "Authentication attempts stable across major nodes. 12% increase in blocked SQLi attempts on external facing load balancers.",
        anomalyDetections: mockAnomalies.map(a => `${a.type}: ${a.description}`),
        threatIntelligenceUpdates: mockThreatIntelligence,
      });
      setBriefing(result.briefing);
    } catch (error) {
      console.error("Briefing generation failed:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  useEffect(() => {
    generateBriefing();
  }, []);

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <div className="w-64 flex-shrink-0">
        <SidebarNav />
      </div>
      
      <main className="flex-1 overflow-y-auto p-8 space-y-8">
        <header className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-headline font-bold text-foreground">Proactive Briefings</h1>
            <p className="text-muted-foreground">Strategic intelligence synthesized by AegisAI from local data and global trends.</p>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" className="border-border">
              <Calendar className="w-4 h-4 mr-2" />
              Schedule
            </Button>
            <Button 
              onClick={generateBriefing} 
              disabled={isGenerating}
              className="bg-primary text-primary-foreground glow-primary"
            >
              {isGenerating ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Sparkles className="w-4 h-4 mr-2" />}
              Regenerate Briefing
            </Button>
          </div>
        </header>

        <div className="max-w-4xl mx-auto">
          <Card className="glass-panel overflow-hidden border-t-4 border-t-primary">
            <CardHeader className="bg-white/5 border-b border-white/5 py-8">
              <div className="flex items-center justify-between mb-4">
                <Badge variant="outline" className="text-primary border-primary/20 bg-primary/5">
                  CONFIDENTIAL // INTERNAL ONLY
                </Badge>
                <div className="text-sm font-mono text-muted-foreground">
                  REPORT ID: BRF-{new Date().toISOString().slice(0, 10).replace(/-/g, "")}
                </div>
              </div>
              <CardTitle className="text-3xl font-headline font-bold">Daily Security Posture Briefing</CardTitle>
              <CardDescription className="text-base">
                Synthesized on {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-8">
              {isGenerating ? (
                <div className="py-20 flex flex-col items-center justify-center text-primary space-y-4">
                  <div className="relative">
                    <Loader2 className="w-12 h-12 animate-spin opacity-20" />
                    <Sparkles className="w-6 h-6 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                  </div>
                  <p className="font-headline font-medium">AegisAI is analyzing global intelligence...</p>
                  <p className="text-xs text-muted-foreground">Structuring findings and impact assessments</p>
                </div>
              ) : briefing ? (
                <div className="prose prose-invert max-w-none prose-p:text-muted-foreground prose-headings:text-foreground prose-headings:font-headline">
                  <div className="whitespace-pre-wrap leading-relaxed space-y-4">
                    {briefing}
                  </div>
                  
                  <div className="mt-12 pt-8 border-t border-border/30 grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                      <h4 className="text-sm font-bold uppercase tracking-widest text-primary mb-4">Core Recommendations</h4>
                      <ul className="space-y-3">
                        {['Upgrade Nginx to v1.24.0 on edge cluster', 'Review SSH access logs for service account "Admin_04"', 'Patch CVE-2023-45678 on dev systems'].map((rec, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                            <ChevronRight className="w-4 h-4 mt-0.5 text-accent flex-shrink-0" />
                            {rec}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="flex flex-col justify-end">
                      <div className="flex gap-2 justify-end">
                        <Button variant="outline" size="sm"><Download className="w-4 h-4 mr-2" /> PDF</Button>
                        <Button variant="outline" size="sm"><Share2 className="w-4 h-4 mr-2" /> Share</Button>
                        <Button variant="outline" size="sm"><Printer className="w-4 h-4" /></Button>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="py-20 text-center text-muted-foreground">
                  <FileText className="w-12 h-12 mx-auto mb-4 opacity-10" />
                  <p>No briefing data available. Click regenerate to pull current intelligence.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}